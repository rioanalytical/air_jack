SELECT
    act.*,
    map.`latitude`,
    map.`longitude`
FROM
    `FRAUD_DETECTION_location_translate` act
    LEFT JOIN `FRAUD_DETECTION_lat_long_map` map on act.`location` = map.`city`