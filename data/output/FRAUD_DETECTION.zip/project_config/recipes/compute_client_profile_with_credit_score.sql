SELECT
    client.*,
    credit.`credit_score`,
    credit.`num_loans`,
    credit.`total_credit_limit`,
    credit.`current_utilization`,
    credit.`delinquencies`
FROM
    `FRAUD_DETECTION_client_profile` client
    LEFT JOIN `FRAUD_DETECTION_cleint_credit_profile` credit ON client.`user_id` = credit.`user_id`