SELECT
    cl.*,
    lbl.`is_synthetic` as fraudulent_account
FROM
    `FRAUD_DETECTION_client_profile_with_credit_score` cl
    LEFT JOIN `FRAUD_DETECTION_fraud_labels` lbl ON cl.`user_id` = lbl.`user_id`