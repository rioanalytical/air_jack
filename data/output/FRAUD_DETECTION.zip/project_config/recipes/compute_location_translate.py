# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd
import numpy as np
import datetime
import random
import concurrent.futures
from geopy.geocoders import Nominatim

# --------------------------------------------
# Read recipe inputs
activity_log_with_label = dataiku.Dataset("activity_log_with_label")
activity_df = activity_log_with_label.get_dataframe()

location_map = dataiku.Dataset("location_map")
location_map_df = location_map.get_dataframe()

# --------------------------------------------
# Generate random timestamp between given dates
def random_timestamp():
    start_datetime = datetime.datetime(2024, 4, 1, 0, 0, 0)      # April 1, 2024 00:00:00
    end_datetime = datetime.datetime(2025, 4, 30, 23, 59, 59)   # April 30, 2025 23:59:59

    time_between = end_datetime - start_datetime
    seconds_between = time_between.total_seconds()
    random_seconds = random.randrange(int(seconds_between))
    random_dt = start_datetime + datetime.timedelta(seconds=random_seconds)
    return random_dt

# Add access_timestamp column with random timestamps
activity_df['access_timestamp'] = [random_timestamp() for _ in range(len(activity_df))]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
location_map_df.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
location_map_df.columns

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
location_map_df

# Create the safe_cities list (risky_ind == 0)
safe_cities = location_map_df[location_map_df['risky_ind'] == 0]['city'].unique().tolist()

# Create the risky_cities list (risky_ind == 1)
risky_cities = location_map_df[location_map_df['risky_ind'] == 1]['city'].unique().tolist()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Assign location based on synthetic flag
np.random.seed(42)
def assign_location(row):
    if row['is_synthetic'] == 1:
        return np.random.choice(risky_cities)
    else:
        return np.random.choice(safe_cities)
activity_df['location'] = activity_df.apply(assign_location, axis=1)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Output dataset write
location_translate_df = activity_df

location_translate = dataiku.Dataset("location_translate")
location_translate.write_with_schema(location_translate_df)