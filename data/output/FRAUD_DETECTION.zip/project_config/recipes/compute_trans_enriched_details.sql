select
    `transaction_id`,
    `user_id`,
    `transaction_date`,
    `amount`,
    `transaction_type`,
    `merchant_category`,
    tran_location
from
    (
        SELECT
            `transaction_id`,
            `user_id`,
            `transaction_date`,
            `amount`,
            `transaction_type`,
            `merchant_category`,
            COALESCE(`tran_location`, `alt_city`) as tran_location,
            `is_synthetic`,
            row_number() over (
                partition by
                    `transaction_id`
                order by
                    `tran_location`,
                    `alt_city`,
                    `log_id` desc
            ) as rower
        FROM
            `FRAUD_DETECTION_tran_with_alt_cities`
    ) temp
where
    temp.rower = 1