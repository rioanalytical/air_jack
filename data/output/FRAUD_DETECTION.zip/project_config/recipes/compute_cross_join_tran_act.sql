SELECT
    tr.*,
    ac.`log_id`,
    ac.`access_timestamp` as act_access_timestamp,
    ac.`location` as act_location,
    ac.`geopoint` as act_geopoint
FROM
    `FRAUD_DETECTION_transaction_with_label` tr
    LEFT JOIN `FRAUD_DETECTION_location_translate_prepared` ac ON tr.`user_id` = ac.`user_id`