SELECT distinct
    `log_id`,
    `user_id`,
    `system_accessed`,
    `access_time`,
    `access_type`,
    `location` as act_geo_dev_location,
    `access_timestamp`
FROM
    `FRAUD_DETECTION_location_translate_prepared`