# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
city_lat_long = dataiku.Dataset("city_lat_long")
city_lat_long_df = city_lat_long.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df = city_lat_long_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df = df.dropna()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
couple_df = df[['City','Nearby_City_within_50km']]
couple_inv_df = df[['Nearby_City_within_50km', 'City']]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
new_name = {
    'City' : 'city',
    'Nearby_City_within_50km' : 'alt_city'
}

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
couple_df_remaned = couple_df.rename(columns=new_name)
couple_inv_df_remaned = couple_inv_df.rename(columns=new_name)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df_appended = pd.concat([couple_df_remaned,couple_inv_df_remaned])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df_appended.columns

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
safe_cities = [
    "New York", "Tokyo", "Paris", "Berlin", "Sydney", "Toronto", "San Francisco",
    "Amsterdam", "Singapore", "Seoul", "Dubai", "Zurich", "Vancouver", "Melbourne",
    "Stockholm", "Copenhagen", "Munich", "Hong Kong", "Boston", "Chicago", "Barcelona",
    "Rome", "Vienna", "Brussels", "Madrid", "Oslo", "Dublin", "Lisbon", "Prague",
    "Budapest", "Warsaw", "Helsinki", "Reykjavik", "Auckland", "Montreal",
    "Buenos Aires", "Sao Paulo", "Cape Town", "Shanghai", "Beijing", "Jakarta", "Istanbul",
    "Bangkok", "Kuala Lumpur", "Tel Aviv", "Lima", "Bogota", "Edinburgh",
    "Glasgow", "Detroit", "Minneapolis", "Phoenix", "Denver", "Houston", "Atlanta",
    "Melbourne", "Brisbane", "Adelaide", "Perth", "Vienna", "Valencia",
    "Zurich", "Geneva", "Basel", "Bern", "Luxembourg City", "Reykjavik", "Oslo", "Stockholm",
    "Copenhagen", "Helsinki", "Amsterdam", "Brussels", "Vienna", "Munich", "Frankfurt",
    "Hamburg", "Stuttgart", "Dusseldorf", "Berlin", "Dublin", "Edinburgh", "Glasgow",
    "Birmingham", "Manchester", "Leeds", "Nottingham", "Zurich", "Ljubljana", "Tallinn",
    "Riga", "Vilnius", "Prague", "Warsaw", "Bratislava", "Hague", "Rotterdam", "Utrecht",
    "Malmo", "Gothenburg", "Oslo", "Helsinki", "Turku", "Reykjavik", "Luxembourg",
    "Monaco", "San Marino", "Andorra la Vella", "Vaduz", "Singapore", "Hong Kong",
    "Tokyo", "Osaka", "Yokohama", "Kyoto", "Sydney", "Melbourne", "Brisbane", "Perth",
    "Canberra", "Wellington", "Auckland", "Vancouver", "Toronto", "Calgary", "Ottawa",
    "Montreal", "Quebec City", "Halifax", "San Diego", "Seattle", "Portland", "Denver",
    "Minneapolis", "Salt Lake City", "Austin", "Raleigh", "Charlotte", "Atlanta", "Dallas",
    "Houston", "Boston", "Philadelphia", "Pittsburgh", "Columbus", "Indianapolis",
    "Milwaukee", "Madison", "Cincinnati", "Nashville", "San Jose", "Sacramento",
    "Salt Lake City", "Edmonton", "Winnipeg", "Victoria", "Halifax", "Quebec City",
    "Montpellier", "Lyon", "Toulouse", "Nice", "Nantes", "Bordeaux", "Strasbourg"
]

risky_cities = [
    "Lagos",             # Nigeria
    "Rio de Janeiro",    # Brazil
    "Moscow",            # Russia
    "Nairobi",           # Kenya
    "Dhaka",             # Bangladesh
    "Manila",            # Philippines
    "Bogotá",            # Colombia
    "Miami",             # USA
    "Mexico City",       # Mexico
    "London",            # UK
    #"Madrid",            # Spain
    #"Warsaw",            # Poland
    "Athens"             # Greece
]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df_appended['ind_risky'] = np.nan

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df_appended.loc[df_appended['city'].isin(safe_cities), 'risky_ind'] = 0

# Mark cities in risky_cities as 1
df_appended.loc[df_appended['city'].isin(risky_cities), 'risky_ind'] = 1

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
city_df_with_risk_ind = df_appended[['city','risky_ind','alt_city']]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
city_lat_long_df.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
c1_df = city_lat_long_df[['City','latitude_City','longitude_City']]
c2_df = city_lat_long_df[['Nearby_City_within_50km','latitude','longitude']]
new_name = {
    'City' : 'city',
    'Nearby_City_within_50km' : 'city',
    'longitude_City' : 'longitude',
    'latitude_City' : 'latitude'
}

c1_df_ren = c1_df.rename(columns=new_name)
c2_df_ren = c2_df.rename(columns=new_name)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
c_appended_df = pd.concat([c1_df_ren,c2_df_ren])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
c_appended_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
c_appended_df = c_appended_df.dropna()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
c_appended_df.shape

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

#location_map_df = city_lat_long_df # For this sample code, simply copy input to output


# Write recipe outputs
location_map = dataiku.Dataset("location_map")
location_map.write_with_schema(city_df_with_risk_ind)

# Write recipe outputs
lat_long_map = dataiku.Dataset("lat_long_map")
lat_long_map.write_with_schema(c_appended_df)