SELECT distinct
    `user_id`,
    `total_credit_limit`,
    `credit_score_new` as credit_score,
    `current_utilization_new` as current_utilization,
    `delinquencies`,
    `num_loans`
FROM
    `FRAUD_DETECTION_modifying_truth_of_credit_score`