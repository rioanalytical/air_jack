# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import pandas as pd
import numpy as np

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Read recipe inputs
transaction = dataiku.Dataset("transaction")
transaction_df = transaction.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
def random_date():
    start_date = datetime.date(2024, 4, 1)
    end_date = datetime.date(2025, 4, 30)    
    time_between_dates = end_date - start_date
    days_between_dates = time_between_dates.days
    random_number_of_days = random.randrange(days_between_dates)
    random_date = start_date + datetime.timedelta(days=random_number_of_days)
    return random_date

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import datetime
import random

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE


transaction_df["transaction_date"] = [random_date() for _ in range(len(transaction_df))]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

transaction_processing_df = transaction_df # For this sample code, simply copy input to output


# Write recipe outputs
transaction_processing = dataiku.Dataset("transaction_processing")
transaction_processing.write_with_schema(transaction_processing_df)