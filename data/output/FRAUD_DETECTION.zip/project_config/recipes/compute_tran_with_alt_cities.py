# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
cross_join_tran_act = dataiku.Dataset("cross_join_tran_act")
cross_join_tran_act_df = cross_join_tran_act.get_dataframe()
location_map = dataiku.Dataset("location_map")
location_map_df = location_map.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
cross_join_tran_act_df.head(2)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
location_map_df.head(2)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Create the safe_cities list (risky_ind == 0)
safe_cities = location_map_df[location_map_df['risky_ind'] == 0]['city'].unique().tolist()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
len(safe_cities)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
cross_join_tran_act_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
cross_join_tran_act_df = pd.merge(cross_join_tran_act_df, location_map_df, left_on = 'act_location', right_on='city', how='left')

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
cross_join_tran_act_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Assign location based on synthetic flag
np.random.seed(42)
def assign_location(row):
    if row['is_synthetic'] == 0:        
        return np.random.choice(safe_cities)
cross_join_tran_act_df['tran_location'] = cross_join_tran_act_df.apply(assign_location, axis=1)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
cross_join_tran_act_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
cross_join_tran_act_df['transaction_date'] = cross_join_tran_act_df['act_access_timestamp'].dt.date

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
cross_join_tran_act_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Compute recipe outputs
# TODO: Write here your actual code that computes the outputs
# NB: DSS supports several kinds of APIs for reading and writing data. Please see doc.

tran_with_alt_cities_df = cross_join_tran_act_df # Compute a Pandas dataframe to write into tran_with_alt_cities


# Write recipe outputs
tran_with_alt_cities = dataiku.Dataset("tran_with_alt_cities")
tran_with_alt_cities.write_with_schema(tran_with_alt_cities_df)