SELECT
    `user_profile_with_risk_email_ind`.`user_id` AS `user_id`,
    `user_profile_with_risk_email_ind`.`dob` AS `dob`,
    `user_profile_with_risk_email_ind`.`age_of_user` AS `age_of_user`,
    `user_profile_with_risk_email_ind`.`email` AS `email`,
    `user_profile_with_risk_email_ind`.`email_localpart` AS `email_localpart`,
    `user_profile_with_risk_email_ind`.`email_domain` AS `email_domain`,
    `user_profile_with_risk_email_ind`.`phone` AS `phone`,
    `user_profile_with_risk_email_ind`.`ssn` AS `ssn`,
    `user_profile_with_risk_email_ind`.`address` AS `address`,
    `user_profile_with_risk_email_ind`.`registration_date` AS `registration_date`,
    `user_profile_with_risk_email_ind`.`age_of_acc` AS `age_of_acc`,
    `user_profile_with_risk_email_ind`.`is_synthetic` AS `is_synthetic`,
    `user_profile_with_risk_email_ind`.`email_risk_ind` AS `email_risk_ind`,
    `credit_worthiness_with_labels`.`total_credit_limit` AS `total_credit_limit`,
    `credit_worthiness_with_labels`.`credit_score` AS `credit_score`,
    `credit_worthiness_with_labels`.`current_utilization` AS `current_utilization`,
    `credit_worthiness_with_labels`.`delinquencies` AS `delinquencies`,
    `credit_worthiness_with_labels`.`num_loans` AS `num_loans`,
    act.`sum_``ind_risk_tran_typ``_` AS ind_risk_tran_typ_wt,
    act.`sum_``ind_risk_merch_cat``_` AS ind_risk_merch_cat_wt,
    act.`sum_``ind_risk_dist``_` AS ind_risk_dist_wt
FROM
    `COMPLEX_SOLUTION_SUSHIL_user_profile_with_risk_email_ind` `user_profile_with_risk_email_ind`
    LEFT JOIN `COMPLEX_SOLUTION_SUSHIL_credit_worthiness_with_labels` `credit_worthiness_with_labels` ON `user_profile_with_risk_email_ind`.`user_id` = `credit_worthiness_with_labels`.`user_id`
    LEFT JOIN `COMPLEX_SOLUTION_SUSHIL_act_features` act ON `user_profile_with_risk_email_ind`.`user_id` = act.`user_id`