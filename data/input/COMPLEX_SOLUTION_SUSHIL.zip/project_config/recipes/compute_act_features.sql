SELECT
    `user_id`,
    sum(`ind_risk_tran_typ`),
    sum(`ind_risk_merch_cat`),
    sum(`ind_risk_dist`)
FROM
    `COMPLEX_SOLUTION_SUSHIL_act_tran_geo_palcements_prepared`
GROUP BY
    `user_id`