# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from sklearn.model_selection import train_test_split


# Read recipe inputs
features = dataiku.Dataset("features")
features_df = features.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
features_df.columns

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Stratified train-test split
train_df, test_df = train_test_split(
    features_df,
    test_size=0.2,
    random_state=42,
    stratify=features_df['is_synthetic']
)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
train_df.is_synthetic.value_counts()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
test_df.is_synthetic.value_counts()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE



# Write recipe outputs
test = dataiku.Dataset("test")
test.write_with_schema(test_df)
train = dataiku.Dataset("train")
train.write_with_schema(train_df)