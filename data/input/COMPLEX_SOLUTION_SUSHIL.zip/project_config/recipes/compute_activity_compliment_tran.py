# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
trans_with_fraud_lables = dataiku.Dataset("trans_with_fraud_lables")
trans_with_fraud_lables_df = trans_with_fraud_lables.get_dataframe()
activity_with_fraud_labels = dataiku.Dataset("activity_with_fraud_labels")
activity_with_fraud_labels_df = activity_with_fraud_labels.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
trans_with_fraud_lables_df.head(2)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
trans_with_fraud_lables_df[['transaction_type','is_synthetic']].value_counts()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
trans_with_fraud_lables_df[['merchant_category','is_synthetic']].value_counts()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
trans_with_fraud_lables_df["transaction_date"] = pd.to_datetime(trans_with_fraud_lables_df["transaction_date"])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
trans_with_fraud_lables_df.dtypes

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
activity_with_fraud_labels_df.dtypes

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
activity_with_fraud_labels_df.head(2)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
activity_with_fraud_labels_df["a_date"] = activity_with_fraud_labels_df["access_timestamp"].dt.date
trans_with_fraud_lables_df["a_date"] = trans_with_fraud_lables_df["transaction_date"].dt.date

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
merged_df = trans_with_fraud_lables_df.merge(
    activity_with_fraud_labels_df,
    left_on=["user_id", "a_date"],
    right_on=["user_id", "a_date"],
    how="left"
)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
act_tran = merged_df.drop_duplicates()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
act_tran.transaction_id.value_counts()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE

# Compute recipe outputs
# TODO: Write here your actual code that computes the outputs
# NB: DSS supports several kinds of APIs for reading and writing data. Please see doc.

activity_compliment_tran_df = act_tran # Compute a Pandas dataframe to write into activity_compliment_tran


# Write recipe outputs
activity_compliment_tran = dataiku.Dataset("activity_compliment_tran")
activity_compliment_tran.write_with_schema(activity_compliment_tran_df)