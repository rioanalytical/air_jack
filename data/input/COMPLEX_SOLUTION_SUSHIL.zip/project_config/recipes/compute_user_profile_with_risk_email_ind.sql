SELECT
    usr.*,
    em.risk_ind as email_risk_ind
FROM
    `COMPLEX_SOLUTION_SUSHIL_user_profile_email_disect` usr
    LEFT JOIN (
        SELECT DISTINCT
            email_domain,
            1 as risk_ind
        FROM
            `COMPLEX_SOLUTION_SUSHIL_risky_domains`
    ) em ON usr.email_domain = em.email_domain