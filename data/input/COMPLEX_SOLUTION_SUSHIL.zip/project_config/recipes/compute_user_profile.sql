SELECT
    usr.*,
    lbl.`is_synthetic`
FROM
    `FRAUD_DETECTION_acc_user_profile` usr
    LEFT JOIN `FRAUD_DETECTION_fraud_labels_1` lbl ON usr.`user_id` = lbl.`user_id`