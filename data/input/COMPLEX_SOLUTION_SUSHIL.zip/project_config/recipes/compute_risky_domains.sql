SELECT
    `email_domain`,
    count(*)
FROM
    (
        select
            *
        from
            `COMPLEX_SOLUTION_SUSHIL_user_profile_email_disect`
        where
            `is_synthetic` = 1
    ) temp
group by
    email_domain