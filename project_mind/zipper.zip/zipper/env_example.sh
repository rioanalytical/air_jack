OPENAI_API_KEY=your_openai_api_key_here
MOCK_API_HOST=localhost
MOCK_API_PORT=8000
LLM_MODEL=gpt-4-turbo-preview
EMBEDDING_MODEL=text-embedding-3-small
TEMPERATURE=0.7